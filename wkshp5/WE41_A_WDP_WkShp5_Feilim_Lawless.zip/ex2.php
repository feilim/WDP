<?php 

$a = 1;
$b = 1;

if ($a == 1) 
 	{ 
 		if ($b == 1)
 		{
 			echo 'Variables A and B both have a value of 1';
 		}

 	}
?>