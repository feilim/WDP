function myFunction()
{
	alert('something happened!!');
}

function imgSwap(imgID)
{
	
	newImg = document.getElementById(imgID);
	newImg.src= "images/image1.jpg";
	


}