<?php

//initialise
$area = 22;


 if ($area < 20) 
 { 
 	print "Too small"; 
 } 
 elseif ($area > 20 && $area < 40) 
 { 
 	print "Perfect size"; 
 } 
 elseif ($area > 40 && $area < 60) 
 { 
 	print "Too big"; 
 } 

?>
