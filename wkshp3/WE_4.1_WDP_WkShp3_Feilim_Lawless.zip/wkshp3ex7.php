<?php

//initialise
$width = 4;
$length = 5;
$area = 0;


/*
no need to prompt for input yet.. sides set in code above
*/

// calculate area of rectangle
$area = $width * $length;
//output
print ("The area of a rectangle with a width of " . $width . " and length of " . $length. " is " . $area);

?>
