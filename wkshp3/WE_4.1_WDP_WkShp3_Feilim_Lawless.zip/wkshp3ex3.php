<?php

//set a value
$celsius = 20;

//define somewhere to keep new value
$fahrenheit = $celsius * 1.8 + 32;

//output result
print ("Celcius value of " . $celsius . " is " . $fahrenheit);

?>
