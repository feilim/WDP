 
 <?php
 //my first PHP script

 		echo "Hello web";
 ?>