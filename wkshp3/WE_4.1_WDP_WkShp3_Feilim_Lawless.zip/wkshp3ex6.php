<?php

//initialise
$int1 = 9;
$int2 = 91;
$result = 0;


/*
no need to prompt for input yet.. integers set in code above
*/

// add the two integers together
$result = $int1 + $int2;

//output
print ("The sum of integers " . $int1 . " and " . $int2. " is " . $result);

?>
