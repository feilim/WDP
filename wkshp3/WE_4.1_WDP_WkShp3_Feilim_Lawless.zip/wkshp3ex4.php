<?php

//initialise
$pi = 3.14;
$radius = 10;
$theArea = 0;

/*
no need to prompt for input yet.. radius set in code above
*/

//area = 2 pi R
$theArea = $pi * ($radius * $radius);

//output
print ("The area of a circle of radius " . $radius . " is " . $theArea);

?>
